# Guía de Instalación - Challenge App en Minikube

## Estructura del Helm Chart

```
challenge-app/
├── Chart.yaml
├── values.yaml
└── templates/
    ├── deployment-api.yaml
    ├── deployment-cache.yaml
    ├── deployment-data.yaml
    ├── deployment-pos.yaml
    ├── services.yaml
    ├── db-redis.yaml
    ├── hpa.yaml
    ├── ingress.yaml
    └── secrets.yaml
```

## Pre-requisitos

1. **Minikube instalado y ejecutándose**
2. **kubectl configurado**
3. **Helm 3 instalado**
4. **Metrics Server habilitado** (para HPA)

## Paso 1: Preparar Minikube

```bash
# Iniciar Minikube con recursos suficientes
minikube start --cpus=4 --memory=8192 --disk-size=20g

# Habilitar metrics-server para HPA
minikube addons enable metrics-server

# Habilitar Ingress Controller (IMPORTANTE para LoadBalancer)
minikube addons enable ingress

# Verificar que metrics-server esté corriendo
kubectl get deployment metrics-server -n kube-system

# Verificar que ingress-nginx esté corriendo
kubectl get pods -n ingress-nginx
```

## Paso 2: Construir las imágenes en Minikube

```bash
# Apuntar Docker al daemon de Minikube
eval $(minikube docker-env)

# Construir las imágenes desde tu directorio del proyecto
cd /ruta/a/tu/proyecto

docker build --build-arg MODULE=data -t challenge-data:latest .
docker build --build-arg MODULE=cache -t challenge-cache:latest .
docker build --build-arg MODULE=pos -t challenge-pos:latest .
docker build --build-arg MODULE=api -t challenge-api:latest .

# Verificar que las imágenes estén disponibles
docker images | grep challenge
```

## Paso 3: Crear el Helm Chart

```bash
# Crear directorio para el chart
mkdir -p challenge-app/templates

# Copiar todos los archivos YAML generados en la estructura correcta
# (usa los artifacts que te compartí)
```

## Paso 4: Personalizar values.yaml (Opcional)

Edita `values.yaml` si necesitas cambiar:
- Passwords de PostgreSQL y Redis
- Recursos de CPU/Memoria
- Límites de HPA
- Puertos

```bash
nano challenge-app/values.yaml
```

## Paso 5: Instalar el Chart

```bash
# Instalar el chart
helm install challenge-release ./challenge-app

# O con valores personalizados
helm install challenge-release ./challenge-app \
  --set secrets.postgresPassword=mipassword \
  --set secrets.redisPassword=redispassword
```

## Paso 6: Verificar el despliegue

```bash
# Ver todos los pods
kubectl get pods

# Ver los servicios
kubectl get svc

# Ver los HPAs
kubectl get hpa

# Ver logs de un pod específico (por ejemplo api)
kubectl logs -f deployment/api

# Ver el estado del PVC de PostgreSQL
kubectl get pvc
```

## Paso 7: Acceder a la aplicación

```bash
# Obtener la IP del Ingress
kubectl get ingress challenge-ingress

# Agregar el dominio al archivo hosts de tu sistema
# En Linux/Mac:
echo "$(minikube ip) challenge.local" | sudo tee -a /etc/hosts

# En Windows (como Administrador):
# Agregar a C:\Windows\System32\drivers\etc\hosts:
# <minikube-ip> challenge.local

# Verificar que funcione
curl http://challenge.local/actuator/health

# O abrir en el navegador
# http://challenge.local
```

La aplicación estará disponible en **http://challenge.local**

### Alternativa sin modificar hosts:

```bash
# Obtener la IP de Minikube
minikube ip

# Acceder directamente con la IP
curl http://<minikube-ip>/actuator/health
```

## Comandos útiles

### Ver el estado del Ingress

```bash
# Ver el Ingress
kubectl get ingress

# Describir el Ingress
kubectl describe ingress challenge-ingress

# Ver logs del Ingress Controller
kubectl logs -n ingress-nginx -l app.kubernetes.io/name=ingress-nginx
```

### Actualizar el chart después de cambios

```bash
helm upgrade challenge-release ./challenge-app
```

### Ver el historial de releases

```bash
helm history challenge-release
```

### Hacer rollback

```bash
helm rollback challenge-release 1
```

### Desinstalar

```bash
helm uninstall challenge-release

# Eliminar también el PVC si es necesario
kubectl delete pvc postgres-pvc
```

### Ver logs de todos los servicios

```bash
# Data
kubectl logs -f deployment/data

# Cache
kubectl logs -f deployment/cache

# Pos
kubectl logs -f deployment/pos

# API
kubectl logs -f deployment/api

# PostgreSQL
kubectl logs -f deployment/db

# Redis
kubectl logs -f deployment/redis
```

### Verificar HPA en acción

```bash
# Ver el estado de los HPAs
kubectl get hpa --watch

# Generar carga (ejemplo con hey o ab)
# Instalar hey: go install github.com/rakyll/hey@latest
hey -z 60s -c 10 http://$(minikube ip):30087/actuator/health
```

### Debugging

```bash
# Describir un pod con problemas
kubectl describe pod <pod-name>

# Ejecutar un shell dentro de un pod
kubectl exec -it deployment/api -- /bin/bash

# Ver eventos del cluster
kubectl get events --sort-by=.metadata.creationTimestamp

# Verificar conectividad entre servicios
kubectl run -it --rm debug --image=busybox --restart=Never -- sh
# Dentro del pod:
# nc -zv data 8089
# nc -zv cache 8088
# nc -zv pos 8090
# nc -zv db 5432
# nc -zv redis 6379
```

## Troubleshooting común

### Pods en estado CrashLoopBackOff

```bash
# Ver logs del pod que falla
kubectl logs <pod-name>

# Ver eventos
kubectl describe pod <pod-name>
```

**Posibles causas:**
- Imágenes no construidas en el daemon de Minikube
- Health checks fallando (aumenta `initialDelaySeconds`)
- Variables de entorno incorrectas

### HPA no escala

```bash
# Verificar metrics-server
kubectl top nodes
kubectl top pods

# Si falla, reiniciar metrics-server
kubectl rollout restart deployment metrics-server -n kube-system
```

### Bases de datos no se conectan

```bash
# Verificar que los init containers terminaron correctamente
kubectl describe pod <pod-name>

# Verificar conectividad
kubectl exec -it deployment/api -- nc -zv db 5432
```

### Ingress no funciona

```bash
# Verificar que el addon de ingress esté habilitado
minikube addons list | grep ingress

# Si no está habilitado
minikube addons enable ingress

# Verificar los pods del ingress controller
kubectl get pods -n ingress-nginx

# Ver logs del controller
kubectl logs -n ingress-nginx deployment/ingress-nginx-controller

# Verificar que el Ingress tenga una IP asignada
kubectl get ingress
# Debe mostrar una ADDRESS

# Probar conectividad directa al servicio
kubectl port-forward service/api 8768:8768
# Luego acceder desde otra terminal: curl localhost:8768/actuator/health
```

### Error "no endpoints available"

```bash
# Verificar que los pods estén Running y Ready
kubectl get pods

# Verificar endpoints
kubectl get endpoints

# Si los endpoints están vacíos, revisar los labels
kubectl get pods --show-labels
kubectl describe service api
```

## Notas importantes

1. **imagePullPolicy: Never** - Las imágenes deben estar en el daemon de Minikube
2. **InitContainers** - Aseguran que las dependencias estén listas antes de iniciar
3. **Health checks** - Pueden tardar 60 segundos en pasar (Spring Boot tarda en iniciar)
4. **PVC** - El volumen de PostgreSQL persiste los datos entre reinicios
5. **Ingress con nginx** - El addon de Minikube proporciona el controlador
6. **LoadBalancer** - En Minikube funciona con el Ingress Controller habilitado
7. **challenge.local** - Dominio configurado para pruebas locales (modificar /etc/hosts)

## Siguientes pasos

Una vez verificado que todo funciona en Minikube:

1. Pushear las imágenes a un registry real (Docker Hub, ECR, GCR)
2. Cambiar `imagePullPolicy: Never` a `imagePullPolicy: IfNotPresent`
3. Configurar un dominio real en el Ingress para producción
4. Habilitar TLS/SSL con cert-manager para HTTPS
5. Configurar valores diferentes para dev/staging/prod
6. Agregar NetworkPolicies para seguridad
7. Implementar monitoring con Prometheus/Grafana
8. Usar un LoadBalancer real en cloud (AWS ELB, GCP LB, Azure LB)