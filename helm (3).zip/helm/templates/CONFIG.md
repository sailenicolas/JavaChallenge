# Configuraciones Avanzadas de Ingress

## Configuración Básica (Ya incluida)

La configuración por defecto expone el servicio API en `http://challenge.local/`

## Configuración con múltiples rutas

Si quieres exponer diferentes servicios en diferentes rutas, edita `values.yaml`:

```yaml
ingress:
  enabled: true
  name: challenge-ingress
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
  hosts:
    - host: challenge.local
      paths:
        - path: /api
          pathType: Prefix
          serviceName: api
          servicePort: 8768
        - path: /data
          pathType: Prefix
          serviceName: data
          servicePort: 8089
        - path: /cache
          pathType: Prefix
          serviceName: cache
          servicePort: 8088
```

Luego necesitarías configurar rewrite en las annotations:

```yaml
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /$2
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
```

Y cambiar los paths a:

```yaml
        - path: /api(/|$)(.*)
          pathType: ImplementationSpecific
          serviceName: api
          servicePort: 8768
```

## Configuración con TLS/HTTPS

### 1. Generar certificado self-signed para desarrollo:

```bash
# Crear certificado
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout tls.key -out tls.crt \
  -subj "/CN=challenge.local/O=challenge.local"

# Crear Secret en Kubernetes
kubectl create secret tls challenge-tls \
  --key tls.key \
  --cert tls.crt
```

### 2. Actualizar values.yaml:

```yaml
ingress:
  enabled: true
  name: challenge-ingress
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    cert-manager.io/cluster-issuer: "letsencrypt-prod"  # Para producción
  hosts:
    - host: challenge.local
      paths:
        - path: /
          pathType: Prefix
          serviceName: api
          servicePort: 8768
  tls:
    - secretName: challenge-tls
      hosts:
        - challenge.local
```

### 3. Acceder con HTTPS:

```bash
# Agregar al /etc/hosts si no lo hiciste
echo "$(minikube ip) challenge.local" | sudo tee -a /etc/hosts

# Acceder (acepta certificado self-signed)
curl -k https://challenge.local/actuator/health

# O en el navegador
# https://challenge.local
```

## Configuración para múltiples dominios

```yaml
ingress:
  enabled: true
  name: challenge-ingress
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
  hosts:
    - host: api.challenge.local
      paths:
        - path: /
          pathType: Prefix
          serviceName: api
          servicePort: 8768
    - host: admin.challenge.local
      paths:
        - path: /
          pathType: Prefix
          serviceName: data
          servicePort: 8089
```

No olvides agregar ambos dominios al `/etc/hosts`:

```bash
echo "$(minikube ip) api.challenge.local admin.challenge.local" | sudo tee -a /etc/hosts
```

## Configuración con Rate Limiting

```yaml
ingress:
  enabled: true
  name: challenge-ingress
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/limit-rps: "10"  # 10 requests por segundo
    nginx.ingress.kubernetes.io/limit-rpm: "600"  # 600 requests por minuto
    nginx.ingress.kubernetes.io/limit-connections: "10"  # 10 conexiones simultáneas
```

## Configuración con CORS

```yaml
ingress:
  enabled: true
  name: challenge-ingress
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/enable-cors: "true"
    nginx.ingress.kubernetes.io/cors-allow-methods: "GET, POST, PUT, DELETE, OPTIONS"
    nginx.ingress.kubernetes.io/cors-allow-origin: "*"
    nginx.ingress.kubernetes.io/cors-allow-credentials: "true"
```

## Configuración con Basic Auth

### 1. Crear archivo de usuarios:

```bash
# Instalar htpasswd (si no lo tienes)
# Ubuntu/Debian: apt-get install apache2-utils
# Mac: brew install apache2

# Crear usuario
htpasswd -c auth admin
# Te pedirá la contraseña

# Crear Secret
kubectl create secret generic basic-auth --from-file=auth
```

### 2. Actualizar annotations:

```yaml
ingress:
  enabled: true
  name: challenge-ingress
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/auth-type: basic
    nginx.ingress.kubernetes.io/auth-secret: basic-auth
    nginx.ingress.kubernetes.io/auth-realm: 'Authentication Required'
```

## Configuración con Sticky Sessions

```yaml
ingress:
  enabled: true
  name: challenge-ingress
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/affinity: "cookie"
    nginx.ingress.kubernetes.io/session-cookie-name: "route"
    nginx.ingress.kubernetes.io/session-cookie-expires: "172800"
    nginx.ingress.kubernetes.io/session-cookie-max-age: "172800"
```

## Configuración con Timeout personalizado

```yaml
ingress:
  enabled: true
  name: challenge-ingress
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/proxy-connect-timeout: "600"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "600"
    nginx.ingress.kubernetes.io/proxy-read-timeout: "600"
    nginx.ingress.kubernetes.io/proxy-body-size: "50m"  # Max upload size
```

## Verificar configuración aplicada

```bash
# Ver la configuración del Ingress
kubectl describe ingress challenge-ingress

# Ver la configuración de nginx generada
kubectl exec -n ingress-nginx deployment/ingress-nginx-controller -- cat /etc/nginx/nginx.conf | grep -A 20 "server_name challenge.local"

# Ver logs en tiempo real
kubectl logs -n ingress-nginx -l app.kubernetes.io/name=ingress-nginx -f
```

## Monitoreo del Ingress

```bash
# Métricas del Ingress Controller
kubectl top pods -n ingress-nginx

# Dashboard de métricas (si tienes Prometheus)
kubectl port-forward -n ingress-nginx service/ingress-nginx-controller-metrics 10254:10254

# Acceder a http://localhost:10254/metrics
```

## Testing de carga con Ingress

```bash
# Instalar hey
go install github.com/rakyll/hey@latest

# Test de carga básico
hey -z 30s -c 10 http://challenge.local/actuator/health

# Test con rate limiting
hey -z 60s -c 50 -q 100 http://challenge.local/actuator/health

# Ver cómo responde el HPA
kubectl get hpa --watch
```

## Producción - AWS ELB

Para producción en AWS, cambiarías el tipo de servicio:

```yaml
service:
  type: LoadBalancer
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-type: "nlb"  # Network Load Balancer
    service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled: "true"
    
ingress:
  enabled: true
  className: alb  # AWS ALB Ingress Controller
  annotations:
    alb.ingress.kubernetes.io/scheme: internet-facing
    alb.ingress.kubernetes.io/target-type: ip
    alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
    alb.ingress.kubernetes.io/certificate-arn: arn:aws:acm:region:account:certificate/xxx
```

## Producción - GCP

```yaml
ingress:
  enabled: true
  className: gce
  annotations:
    kubernetes.io/ingress.class: "gce"
    kubernetes.io/ingress.global-static-ip-name: "challenge-ip"
    networking.gke.io/managed-certificates: "challenge-cert"
```